package sample;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;




public class DataBase {
    private Connection dataBaseLink;
    public  Connection getconnection(){
        String databaseName="Trip";
        String databaseUser ="houda";
        String databasePass="ff613658sx16028";
        String url = "jdbc:mysql://localhost/"+databaseName;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            //Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            //Class.forName("postgresql.Driver");
            dataBaseLink=DriverManager.getConnection(url,databaseUser,databasePass);
            //String DBurl = "jdbc:odbc:testDB";
            //con = DriverManager.getConnection(DBurl);

        }catch (Exception e){
            e.printStackTrace();
            e.getCause();
        }
    return dataBaseLink;
    }


}
